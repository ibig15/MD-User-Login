package model;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;

import org.apache.commons.lang3.ArrayUtils;

@Entity
@Table(name = "MyAppUser")
public class MyAppUser {
	
	@Id
	private String email;
	private String name;
	private boolean loggedIn;
	@Lob
	private byte[] salt;
	private String password;
	private int incorrectPasswordCount;
	
	public MyAppUser(){}
	
	public MyAppUser(String email, String password, String name) {
		super();
		this.email = email;
		MyPassword(password, LocalDateTime.now().plusYears(1), 0);
		this.name = name;
		this.loggedIn = true;
	}
	
	public MyAppUser(String email, String password, String name, boolean active, int incorrectPasswordCount) {
		super();
		this.email = email;
		MyPassword(password, LocalDateTime.now().plusYears(1), 0);
		this.name = name;
		this.loggedIn = active;
	}
	
	public String getEmail() {
		return email;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}
	
	public void MyPassword(String password, LocalDateTime localDateTime) {
		setPassword(password);
		this.incorrectPasswordCount = 0;
	}
	
	public void MyPassword(String password, LocalDateTime localDateTime, int incorrectPasswordCount) {
		setPassword(password);
		this.incorrectPasswordCount = incorrectPasswordCount;
	}
	
	public boolean doesPasswordMatch(String pass){
		String encryptedPass = encryptPassword(this.salt, pass);
			
		char[] existingPass = this.password.toCharArray();
		char[] newPass = encryptedPass.toCharArray();
		int diff = existingPass.length ^ newPass.length;
		for(int i = 0; i < existingPass.length && i < newPass.length; i++)
			diff |= existingPass[i] ^ newPass[i];
		return diff == 0;
	}
	
	public void setPassword(String password) {
		setSalt();
		this.password = encryptPassword(this.salt, password);
	}
	
	private String encryptPassword(byte[] salt, String pass){
		try {
			byte[] saltedPass = ArrayUtils.addAll(salt, pass.getBytes("UTF-8"));
			MessageDigest md = MessageDigest.getInstance("SHA-256");
			md.update(saltedPass); // or "UTF-16"
			byte[] hashedBytes = md.digest();
			return bytesToHexString(hashedBytes);
		} catch (NoSuchAlgorithmException|UnsupportedEncodingException exc) {
			throw new RuntimeException("Could not encrypt password. ", exc);
		}
	}
	
	private String bytesToHexString(byte[] arrayBytes) {
	    StringBuffer hexString = new StringBuffer();
	    for (int i = 0; i < arrayBytes.length; i++) {
	    	hexString.append(Integer.toString((arrayBytes[i] & 0xff) + 0x100, 16).substring(1));
	    }
	    return hexString.toString();
	}
	
	@Lob
	private byte[] getSalt() {
		return salt;
	}

	private void setSalt() {
		SecureRandom random = new SecureRandom();
		byte[] salt = new byte[32];
		random.nextBytes(salt);
		this.salt = salt;
		/*try {
			this.salt = new javax.sql.rowset.serial.SerialBlob(salt);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
	}
	
	public int getIncorrectPasswordCount() {
		return incorrectPasswordCount;
	}
	
	public void setIncorrectPasswordCount(int incorrectPasswordCount) {
		this.incorrectPasswordCount = incorrectPasswordCount;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public boolean getLoggedIn() {
		return loggedIn;
	}
	
	public void setLoggedIn(boolean active) {
		this.loggedIn = active;
	}
		
	@Override
	public String toString() {
		return "AppUser [email=" + email + ", password=" + password + ", name=" + name + ", salt=" + salt 
				+ ", incorrectPasswordCount=" + incorrectPasswordCount + ", LoggedIn=" + loggedIn + "]";
	}

}


