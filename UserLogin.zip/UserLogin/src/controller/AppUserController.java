package controller;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

import model.*;
import model.UserMessage.message;


public class AppUserController {
	private final String PERSISTENCE_UNIT_NAME = "MyUsers";
	
	private EntityManagerFactory factory;
	private EntityManager em;
	
	public AppUserController()
	{
		this.factory = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	    this.em = factory.createEntityManager();
	}
	
	public void close()
	{
		this.em.close();
	}
	
	public List<MyAppUser> getRegisteredUsers()
	{
		Query q = em.createQuery("select u from MyAppUser u");// inner join Password p on u.PASSWORD_ID = p.id");
		//Query q = em.createQuery("select p from MyPassword p");
        List<MyAppUser> registeredUsers = q.getResultList();
        return registeredUsers;
	}
	
	public List<MyAppUser> getLoggedInUsers()
	{
		Query q = em.createQuery("select u from MyAppUser u where u.loggedIn = true");
        List<MyAppUser> loggedInUsers = q.getResultList();
        return loggedInUsers;
	}
	
	public message registerUser(String email, String password, String name)
	{
		// check email is correct
		boolean isValidEmail = validateEmail(email);
		if (!isValidEmail){
			return message.InvalidEmailOrPassword;
		}
		
		// check email doesn't already exist in the db
		boolean emailAlreadyExists = checkUserEmailExists(email);
		if (emailAlreadyExists){
	    	return message.ExistingEmail;
	    }
		
		try {
			// add/register user in the db
			MyAppUser user = new MyAppUser(email, password, name, true, 0);
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
		    return message.SuccesfulRegistration;
		}
		catch (Exception exc) {
			return message.DbError;
		}
	}
	
	private boolean validateEmail(String email) {
		Pattern EMAIL_ADDRESS_REGEX = 
				Pattern.compile("^[A-Z0-9._%+-]+@[A-Z0-9.-]+\\.[A-Z]{2,6}$", Pattern.CASE_INSENSITIVE);
        Matcher matcher = EMAIL_ADDRESS_REGEX.matcher(email);
        return matcher.find();
	}
	
	private boolean checkUserEmailExists(String email){
		Query q1 = em.createQuery("select u from MyAppUser u where u.email = :email");
		q1.setParameter("email", email);
		List<MyAppUser> existingUser = q1.getResultList();
		return (existingUser.size() == 1) ? true:false;
	}
	
	public List<MyAppUser> findUser(String email){
		Query q = em.createQuery("select u from MyAppUser u where u.email = :email");
		q.setParameter("email", email);
		List<MyAppUser> existingUser = q.getResultList();
		return existingUser;
	}
	
	public message logInUser(String email, String password){
		List<MyAppUser> existingUser = findUser(email);
		
		if (existingUser.size() != 1){	// check if email exists in the db
	    	return message.UserNotRegistered;
	    }
	    else if (!existingUser.get(0).doesPasswordMatch(password)){ // check if the password matches
			// increase Incorrect Password Count
	    	MyAppUser user = existingUser.get(0);
			int incorrectPassCount = user.getIncorrectPasswordCount() + 1;
			user.setIncorrectPasswordCount(incorrectPassCount);
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
		    
			return message.InvalidEmailOrPassword;
		}
		else if (existingUser.get(0).getIncorrectPasswordCount() >= 5){	// check if account is blocked because the password was introduced incorrectly 5 times
			return message.BlockedUser;
		}
		else{	// else log in correctly
			MyAppUser user = existingUser.get(0);
			user.setLoggedIn(true);
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
		    return message.SuccessfulLogin;
		}
	}
	
	public message logOutUser(String email){
		List<MyAppUser> existingUser = findUser(email);
		
		if (existingUser.size() != 1){	// check if email exists in the db
	    	return message.UserNotRegistered;
	    }
	    else{	// else log out user
			MyAppUser user = existingUser.get(0);
			user.setLoggedIn(false);
			em.getTransaction().begin();
			em.persist(user);
			em.getTransaction().commit();
		    return message.SuccessfulLogout;
		}
	}

	public message deleteUser(String email){
		List<MyAppUser> existingUser = findUser(email);
		
		if (existingUser.size() != 1){	// check if email exists in the db
	    	return message.UserNotRegistered;
	    }
		else{
			em.getTransaction().begin();
			em.remove(existingUser.get(0));
		    em.getTransaction().commit();
			return message.UserDeleted;
		}
	}
}
